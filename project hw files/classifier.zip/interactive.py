int('10  \n')

"hello %d" % 10

x = range(10)
x
x[-3:]
x[:2]
x[-2:]

import util
a = util.Counter()
b = util.Counter()
a[1] = 10
a[2] = 20
b[1] = -10
b[2] = -20
a+b 
a+=b 
a 
a-=b 
a 
